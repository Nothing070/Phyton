def jumlah(a, b):
    hasil = a + b
    return hasil

def kali(a, b):
    hasil = a * b
    return hasil

def kurang(a, b):
    hasil = a - b
    return hasil

def bagi(a, b):
    hasil = a / b
    return hasil
