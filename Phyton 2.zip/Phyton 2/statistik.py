def jumlah(*data):
    total = 0
    for angka in data:
        total += angka
    return total

def rata_rata(*data):
    return jumlah(*data) / len(data)

def nilai_maks(*data):
    maksimum = data[0]
    for angka in data:
        if angka > maksimum:
            maksimum = angka
    return maksimum

def nilai_min(*data):
    minimum = data[0]
    for angka in data:
        if angka < minimum:
            minimum = angka
    return minimum
