def faktorial(n):
    hasil = 1
    for i in range(1, n + 1):
        hasil *= i
    return hasil

def kombinasi(n, r):
    return faktorial(n) // (faktorial(r) * faktorial(n - r))

print("C(5, 3) =", kombinasi(5, 3))

def permutasi(n, r):
    return faktorial(n) // faktorial(n - r)

print("P(10, 7) =", permutasi(10, 7))
