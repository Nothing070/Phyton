def starFormation1(n):
    for i in range(1, n + 1):
        print('*' * i)

def starFormation2(n):
    for i in range(n, 0, -1):
        print('*' * i)

def starFormationFull(n):
    half = n // 2
    starFormation1(half)
    starFormation2(n - half)

starFormationFull(7)
