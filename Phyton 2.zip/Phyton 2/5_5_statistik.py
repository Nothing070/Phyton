from statistik import rata_rata, nilai_maks, nilai_min

# Data A
a = [5, 10, 4, 9, 30, 16, 2, 11]
print("Data A:")
print("Rata-rata :", rata_rata(*a))
print("Maksimum  :", nilai_maks(*a))
print("Minimum   :", nilai_min(*a))

# Data B
b = [81, 98, 12, 83, 45, 77, 69, 30, 56]
print("\nData B:")
print("Rata-rata :", rata_rata(*b))
print("Maksimum  :", nilai_maks(*b))
print("Minimum   :", nilai_min(*b))
