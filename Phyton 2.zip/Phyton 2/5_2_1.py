def starFormation1(n):
    for i in range(1, n + 1):
        print('*' * i)

starFormation1(4)
