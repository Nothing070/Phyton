def jumlah(a, b):
    hasil = a + b
    return hasil

a = 10
b = 20
hasil = jumlah(a, b)
print(hasil)

def myFunction():
    a = 20
    print(a)

a = 10
myFunction()
print(a)
