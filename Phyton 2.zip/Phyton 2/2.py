def luasSegitiga(a, t):
    luas = a * t / 2
    return luas

alas = 15
tinggi = 45
print('Luas segitiga dengan alas', alas,
      'dan tinggi', tinggi,
      'adalah', luasSegitiga(alas, tinggi))

def luasSegitiga2(a, t):
    luas = a * t / 2
    print('Luas segitiga dengan alas', a,
          'dan tinggi', t,
          'adalah', luas)

alas = 15
tinggi = 45
luasSegitiga2(alas, tinggi)

def luasSegitiga(alas, tinggi):
    return alas * tinggi / 2

# Data segitiga pertama
alas1 = 10
tinggi1 = 20
luas1 = luasSegitiga(alas1, tinggi1)

# Data segitiga kedua
alas2 = 15
tinggi2 = 45
luas2 = luasSegitiga(alas2, tinggi2)

totalLuas = luas1 + luas2

print("Luas segitiga pertama adalah:", luas1)
print("Luas segitiga kedua adalah:", luas2)
print("Total luas kedua segitiga adalah:", totalLuas)
