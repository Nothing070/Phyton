from operation import *

step1_a = kali(4, 6)
step2_a = jumlah(2, step1_a)
hasil_a = kurang(step2_a, 4)
print("Hasil a. 2 + 4 * 6 - 4 =", hasil_a)

step1_b = jumlah(4, 7)
step2_b = kurang(6, 9) 
hasil_b = kali(step1_b, step2_b)
print("Hasil b. (4 + 7) * (6 - 9) =", hasil_b)

step1_c = jumlah(10, 2) 
step2_c = jumlah(7, 5) 
step3_c = kurang(12, 34) 
step4_c = bagi(step1_c, step2_c) 
hasil_c = bagi(step4_c, step3_c)
print("Hasil c. (10 + 2) / (7 + 5) / (12 - 34) =", hasil_c)
