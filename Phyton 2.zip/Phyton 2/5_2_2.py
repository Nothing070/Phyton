def starFormation2(n):
    for i in range(n, 0, -1):
        print('*' * i)

starFormation2(4)
