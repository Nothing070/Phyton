def isPythagoras(a, b, c):
    return a * a + b * b == c * c

print(isPythagoras(3, 4, 5))
print(isPythagoras(5, 9, 12))
print(isPythagoras(8, 6, 10))
print(isPythagoras(7, 8, 11))