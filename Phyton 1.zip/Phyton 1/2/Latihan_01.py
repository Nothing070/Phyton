x = 10
print(type(x))
y = 20
print(type(y))
print(type(x+y))