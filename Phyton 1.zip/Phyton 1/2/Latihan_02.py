a = 10
p = y = x = z = a
print(a)
print(z)
print(x)
print(y)
print(p)