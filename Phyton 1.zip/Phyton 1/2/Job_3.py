# Menghitung berapa kali pengisian bensin
def hitung_pengisian_bbm(liter_bbm, kapasitas_tangki):
    # Hitung berapa kali pengisian yang dibutuhkan
    jumlah_pengisian = liter_bbm / kapasitas_tangki
    # Jika ada sisa, maka perlu pengisian tambahan
    if liter_bbm % kapasitas_tangki != 0:
        jumlah_pengisian += 1
    return int(jumlah_pengisian)

# Kapasitas tangki mobil
kapasitas_tangki = 50
liter_bbm = 66.25

jumlah_pengisian = hitung_pengisian_bbm(liter_bbm, kapasitas_tangki)
print(f"Jumlah pengisian bensin minimal yang dibutuhkan: {jumlah_pengisian} kali")