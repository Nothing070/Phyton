# Menghitung jumlah liter bensin yang diperlukan
def konsumsi_bbm(jarak, konsumsi_per_12_km):
    liter_bbm = jarak / konsumsi_per_12_km
    return liter_bbm

# Jarak perjalanan dan konsumsi bbm mobil
jarak_perjalanan = 795
konsumsi_bbm_per_12_km = 12

liter_bbm = konsumsi_bbm(jarak_perjalanan, konsumsi_bbm_per_12_km)
print(f"Jumlah liter bensin yang dibutuhkan: {liter_bbm:.2f} liter")