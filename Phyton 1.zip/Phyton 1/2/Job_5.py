import matplotlib.pyplot as plt

# Data jumlah siswa
laki_laki = 28
perempuan = 4

# Membuat grafik batang horizontal
plt.barh(['Laki-laki', 'Perempuan'], [laki_laki, perempuan], color=['blue', 'pink'])

# Menambahkan label dan judul
plt.xlabel('Jumlah Siswa')
plt.title('Jumlah Siswa Laki-laki dan Perempuan')

# Menampilkan jumlah di atas batang
for i, v in enumerate([laki_laki, perempuan]):
    plt.text(v + 2, i, str(v), va='center')

# Menampilkan grafik
plt.show()