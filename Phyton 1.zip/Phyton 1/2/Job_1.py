# Menghitung tarif sewa mobil
def tarif_sewa_mobil(jam_awal, jam_akhir):
    # Menghitung total jam penyewaan
    jam_sewa = (jam_akhir - jam_awal) % 24
    
    # Tarif sewa
    tarif_12_jam_pertama = 200000
    tarif_setelah_12_jam = 10000

    # Jika penyewaan kurang dari 12 jam, cukup bayar tarif 200000
    if jam_sewa <= 12:
        total_tarif = tarif_12_jam_pertama
    else:
        # Hitung jam setelah 12 jam pertama
        jam_tambahan = jam_sewa - 12
        total_tarif = tarif_12_jam_pertama + (tarif_setelah_12_jam * jam_tambahan)
    
    return total_tarif

# Contoh waktu penyewaan
jam_awal = 6
jam_akhir = 23 + (50/60)
total_tarif = tarif_sewa_mobil(jam_awal, jam_akhir)
print(f"Total tarif yang harus dibayar: Rp {total_tarif}")