# Menghitung waktu sampai di kota C
def waktu_sampai(km_a_b, km_b_c, kecepatan_a_b, kecepatan_b_c, istirahat):
    # Waktu perjalanan A ke B
    waktu_a_b = km_a_b / kecepatan_a_b
    # Waktu perjalanan B ke C
    waktu_b_c = km_b_c / kecepatan_b_c
    # Total waktu perjalanan
    total_waktu = waktu_a_b + waktu_b_c + (istirahat / 60)
    
    # Waktu keberangkatan pukul 06:00
    jam_keberangkatan = 6
    menit_keberangkatan = 0
    
    # Menghitung waktu sampai
    total_menit = (jam_keberangkatan * 60 + menit_keberangkatan) + (total_waktu * 60)
    jam_tiba = total_menit // 60
    menit_tiba = total_menit % 60
    
    return f"{int(jam_tiba)}:{int(menit_tiba):02d}"

# Parameter perjalanan
km_a_b = 125
km_b_c = 256
kecepatan_a_b = 62
kecepatan_b_c = 70
istirahat = 45

waktu_sampai_di_kota_c = waktu_sampai(km_a_b, km_b_c, kecepatan_a_b, kecepatan_b_c, istirahat)
print(f"Pak Amir sampai di kota C pada pukul: {waktu_sampai_di_kota_c}")