try:
    filename = input("Masukkan nama file: ")
    while True:
        data = input("Data yang mau ditambahkan: ")
        with open(filename, "a") as file:
            file.write(data + "\n")

        lagi = input("Mau lagi (y/n): ")
        if lagi.lower() != 'y':
            break
except IOError:
    print("Error: Terjadi kesalahan saat membuka/menulis file.")
