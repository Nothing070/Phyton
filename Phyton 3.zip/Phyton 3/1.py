file = open("c:/Users/ASM-3-16/documents/myfile.txt", "r")
print(file.read())
