try:

    # membuka dan mau membaca file
    file = open("c:/Users/ASM-3-16/documents/angka.txt", "r")

    # baca baris pertama dari file
    # menyimpan ke dalam variable bilangan 1 sebagai integer
    bil1 = int(file.readline())

    # baca baris pertama dari file
    # menyimpan ke dalam variable bilangan 2 sebagai integer

    bil2 = int(file.readline())

    # hitung dan menampilkan hasil pembagian
    hasil = bil1/bil2
    print(bil1, ' dibagi ', bil2 , ' sama dengan ', hasil)

# Jika file tidak ditemukan
except FileNotFoundError:
    print("File tidak ditemukan")

# Jika bil2 adalah nol
except ZeroDivisionError:
    print("Tidak boleh pembagian dengan nol")

# Jika isi file tidak bisa diubah jadi integer
except ValueError:
    print("Isi file tidak valid — harus berupa angka")

# Penanganan umum (jika ada error lain)
except Exception as e:
    print("Terjadi error:", e)