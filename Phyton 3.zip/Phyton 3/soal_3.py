print("-" * 30)
print("PROGRAM HITUNG RATA-RATA")
print("-" * 30)

total = 0
count = 0

while True:
    try:
        angka = int(input("Masukkan bilangan bulat: "))
        total += angka
        count += 1
    except ValueError:
        print("Bukan bilangan bulat")

    lagi = input("Lagi (y/n)?: ")
    if lagi.lower() != 'y':
        break

if count > 0:
    rata_rata = total / count
    print(f"\nRata-ratanya adalah: {rata_rata}")
else:
    print("\nTidak ada bilangan bulat yang dimasukkan.")
