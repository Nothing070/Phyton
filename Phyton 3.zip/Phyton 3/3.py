try:
    file = open("c:/Users/ASM-3-16/documents/angka2.txt", "r")
    total = 0

    for data in file:
        try:
            total += int(data)
        except ValueError:
            print(f"Data tidak valid dan dilewati : {data.strip()}")

    print("Jumlah total angka dalam file adalah :", total)

except FileNotFoundError:
    print("File tidak ditemukan. Pastikan path dan nama file benar.")
