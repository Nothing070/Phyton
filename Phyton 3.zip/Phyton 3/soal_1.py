filename = input("Masukkan nama file: ")

try:
    with open(filename, "r") as file:
        print(f"Isi file {filename} adalah:\n")
        print(file.read())
except FileNotFoundError:
    print("Error: File tidak ditemukan.")
except IOError:
    print("Error: Terjadi kesalahan saat membuka / membaca file.")
